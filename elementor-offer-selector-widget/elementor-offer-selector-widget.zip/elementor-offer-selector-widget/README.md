# elementor-offer-selector-widget
 This is a plugin that adds an offer selector widget to Elementor.
